from flask import Flask, send_from_directory
from flask_cors import CORS
import os
from view.routes import main_bp

def create_app():
    app = Flask(__name__,
                static_folder=os.path.join(os.path.dirname(__file__), 'view/build'),
                static_url_path='')

    app.secret_key = 'sua_chave_secreta'

    CORS(app, supports_credentials=True, origins=["*"])
    app.register_blueprint(main_bp)

    # Se não for uma rota de API, devolve o React index.html
    @app.route('/')
    @app.route('/<path:path>')
    def serve_react(path=''):
        if path != "" and os.path.exists(os.path.join(app.static_folder, path)):
            return send_from_directory(app.static_folder, path)
        else:
            return send_from_directory(app.static_folder, 'index.html')


    return app
